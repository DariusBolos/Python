from ui.interface import defaultInterface


def main():
    defaultInterface()


main()
